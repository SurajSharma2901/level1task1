
function Footer(){
    return(
        <>
        <footer>
        &copy; 2025 Signor Margarita. All rights reserved.
    </footer>
        </>
    );
}
export default Footer
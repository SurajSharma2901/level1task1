
function Header(){
    return (
        <header>
            <div className="Domain"><h1>Signor Margarita</h1></div>
            <nav className="navbar">
                <ul>
                    <li><a href="#">HOME</a></li>
                    <li><a href="#">ABOUT</a></li>
                    <li><a href="#">SERVICE</a></li>
                    <li><a href="#">CONTACT US</a></li>
                    <div className="search">
                        <input type="text" className="search" id="search" />
                    </div>
                    <div className="order"><a href="#">ORDER NOW</a></div>
                </ul>
            </nav>

        </header>
    );
}
export default Header